使用cyaron生成
input.in/input.out/test.out 规模较大（n = 2e4, m = 3e4），但是由于边多不易生成错误数据，因此边数较小
input1.in/input1.out/test1.out 规模较小（n = 20, m = 50）